# square.py
# Display a square

from turtle import *    # Get graphics stuff

color("blue")
forward(200)
right(90)
forward(200)
right(90)
forward(200)
right(90)
forward(200)

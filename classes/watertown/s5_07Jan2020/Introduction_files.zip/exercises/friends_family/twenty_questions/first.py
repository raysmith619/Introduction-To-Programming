# first 17Jul2018
# loop asking number
# print number entered
while True:
    inp = input("Enter Number ")
    num = int(inp)
    print("Number:", num)
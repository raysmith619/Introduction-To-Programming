#b_mod.py
def b_fun():
    print("b.py")

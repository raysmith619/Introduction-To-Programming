#c_mod.py
def c_fun():
    print("c.py")

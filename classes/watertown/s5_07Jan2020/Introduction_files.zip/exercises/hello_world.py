print("Hello World!")
print("My name is Smith.")


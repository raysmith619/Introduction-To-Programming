# turtle_square.py    26Oct2020 from
#  https://www.youtube.com/watch?v=pxKu2pQ7ILo
# Make a square
import turtle

ray = turtle.Turtle()
ray.color("blue")
ray.forward(100)
ray.left(90)
ray.forward(100)
ray.left(90)
ray.forward(100)
ray.left(90)
ray.forward(100)

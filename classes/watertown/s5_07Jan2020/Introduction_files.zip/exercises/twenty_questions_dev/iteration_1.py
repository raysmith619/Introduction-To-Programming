# iteration_1.py 21Jan2020
# first iteration of twenty questions
# Prompt user for number

while True:
    inp = input("Enter Guess:")
    print("Number:", inp)
   
    


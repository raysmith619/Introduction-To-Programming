#times13.py crs 15Oct2018  original

#times table....
nval =13      # number to multiply
first = 1
last = nval

n = first    # begin at lowest value
while n <= last:
    print(n, "x", nval, n*nval)
    n = n + 1




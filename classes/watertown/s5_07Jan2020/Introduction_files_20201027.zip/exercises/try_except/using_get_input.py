# using_get_input.py 3Feb2020
"""
using function defined in get_input.py
"""
from get_input import get_int

while True:
    num = get_int("Enter integer:")
    print("Number entered:", num)

#input_loop 17-Jul-2018
# loop getting input
while True:
    guess = input("Enter guess ")
    print("guess =", guess)

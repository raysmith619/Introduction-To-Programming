#resource_lib_link.py   25Apr2022  crs, Author
""" Set path to include resource_lib_proj/src
    We assume we are in a sub directory of
    python head of python/resource_lib_proj/src
     OR
    resource_lib_proj
    To avoid duplicated path additions, we
    forgo the search if we already have
    resource_lib_proj/src in our search
"""

import sys
import os
from pathlib import Path

top_dir = "python"
lib_dir = "resource_lib_proj"
src_dir = "src"

for path in sys.path:
    path_dirs =  Path(path).parts
    if (len(path_dirs) >= 2
        and path_dirs[-2] == lib_dir
        and path_dirs[-1] == src_dir):
        print(f"{lib_dir}/{src_dir}is already in path")
        sys.exit(0)
              
wd = os.getcwd()
print(f"cwd:{wd}")
wd_dirs = Path(wd).parts
print(f"wd_dirs:{wd_dirs}")
wdir = None
n = len(wd_dirs)
for i in range(n-1, 0,-1):
    wdir = wd_dirs[i]
    if wdir == top_dir:
        break
    if wdir == lib_dir:
        break
if wdir == "python":
    new_path = os.path.join(*wd_dirs[0:i],"python",
                            "resource_lib_proj", src_dir)
elif wdir == "resource_lib_proj":
    new_path = os.path.join(*wd_dirs[0:i+1],src_dir)
else:
    print(f"Neither {top_dir} nor {lib_dir} found")
    sys.exit(1)
print(f"Adding import path: {new_path}")
sys.path.append(new_path)    
   

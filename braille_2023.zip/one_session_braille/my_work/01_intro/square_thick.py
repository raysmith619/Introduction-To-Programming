# square_thick.py
# Display a square
from turtle_braille_link import *        # Set link to library

color("green")
width(50)
forward(200)
right(90)
forward(200)
right(90)
forward(200)
right(90)
forward(200)
done()

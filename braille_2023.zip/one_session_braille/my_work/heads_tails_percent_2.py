#heads_tails_percent_2.py
import random
import time
n_heads = 0
n_tails = 0
n_max = 9
n = 0
while n < n_max:
	n += 1
	num = random.randint(1,2)
	if num == 1:
		ht="heads"
		n_heads += 1
	else:
		ht="tails"
		n_tails += 1
	print("We got", ht)
	time.sleep(1)
	print("NOW We have:", n_heads,"heads",
              n_tails, "tails")
	hperc = int(n_heads/(n_heads+n_tails)*100)
	time.sleep(1)
	print(hperc, "percent heads")
	time.sleep(3)

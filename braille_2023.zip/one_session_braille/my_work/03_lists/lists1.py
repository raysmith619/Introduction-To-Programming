# list1.py  25Feb2022  crs
# Using lists
list1 = [1,2]
print("list1:", list1)
print("list1.append(4)")
list1.append(4)
print("list1:", list1)
for mem in list1:
    print("mem:", mem)
print("list1[1]:", list1[1])

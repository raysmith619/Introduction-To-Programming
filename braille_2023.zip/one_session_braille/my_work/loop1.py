#list1.py
for i in range(8):
	print(i,i*".")

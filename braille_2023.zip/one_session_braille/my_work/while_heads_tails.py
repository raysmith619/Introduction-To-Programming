#while_heads_tail.py
import random
n_max = 9
n = 0
while n < n_max:
	n += 1
	num = random.randint(1,2)
	if num == 1:
		ht="heads"
	else:
		ht="tails"
	print(ht)

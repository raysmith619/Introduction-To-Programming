# tul_square.py    17Jul2022  crs, from square.py
# Display a square

from turtle_little import *    # Get graphics stuff

color("blue")
forward(400)
right(90)
forward(400)
right(90)
forward(400)
right(90)
forward(400)
done()
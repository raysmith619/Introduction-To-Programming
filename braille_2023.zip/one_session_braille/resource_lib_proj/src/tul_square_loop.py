# tul_square_loop.py
# Display a square

from turtle_little import *

color("red")
for i in range(4):  # Do 4 times
    forward(200)
    right(90)
done()

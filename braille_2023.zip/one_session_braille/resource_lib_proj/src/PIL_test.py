#PIL_test.py
import PIL
print(f"PIL.__version__:{PIL.__version__}")
print(f"PIL.__doc__:{PIL.__doc__}")

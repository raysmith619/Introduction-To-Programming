# logging_absolute_minimum.py    22Feb2020  crs

from select_trace import SlTrace

SlTrace.lg("Just the minimum for logging")



            if self.lfun_x_chg_gt:
                px_chg = p_chg*self.lfun_cos
                pt_x = pt_x + px_chg
                if self.lfun_x_diff > 0:
                    if pt_x > p2[0]:
                        break
                else:
                    if pt_x < pt[0]:
                        break
                pt_y = self.line_y(pt_x)
            else:
                py_chg = p_chg*self.lfun_sin
                pt_y = pt_y + py_chg
                if self.lfun_y_diff > 0:
                    if pt_y > p2[1]:
                        break
                else:
                    if pt_y < p2[1]:
                        break
                pt_x = self.line_x(pt_y)





    def get_points_triangle(self,p1,p2,p3, point_resolution=None):
        """ Get points in triangle
        Strategy fill from left to right
        with vertical lines separated by point_resolution
        Start at x = min_x stopping at x >= max_x
        :p1,p2,p3: triangle points (x,y) tupple
        :point_resolution:  maximum pint separation to avoid
            gaps default: self.point_resolution
        :returns: set of fill points
        """
        SlTrace.lg(f"get_points_triangle:{p1} {p2} {p3}")
        min_x_p = p1
        min_x = p1[0]
        
        # Find min_x, max_x
        # Create pxs a list of the points
        # in ascending x order
        pxs = [min_x_p]    # point to process
                                # starting with min
        for p in [p2,p3]:
            x = p[0]
            if x < min_x:
                min_x = x 
                min_x_p = p
                pxs.insert(0,p)
            elif len(pxs) > 1 and x < pxs[1][0]:
                pxs.insert(1,p)
            else:
                pxs.append(p)
        fill_points = set()    
        # Process traiangle in two steps
        # with increasing x values
        #   pxs[0] to pxs[1]        
        #   psx[1] to pxs[2] 
        SlTrace.lg(f"pxs:{pxs}")
        
        # pxs[0] to pxs[1]   
        line_01_points = self.get_line_points(pxs[0], pxs[1],
                                point_resolution=point_resolution)
        line_02_points = self.get_line_points(pxs[0],pxs[2],
                                point_resolution=point_resolution)
        for i in range(len(line_01_points)):
            p_line_01 = line_01_points[i]
            p_line_02 = line_02_points[i] 
            vert_points = self.get_line_points(p_line_01,p_line_02)
            fill_points.update(vert_points)

        # pxs[1] to pxs[2]
        end_line_01 = len(line_01_points)
        line_12_points = self.get_line_points(pxs[1], pxs[2],
                                point_resolution=point_resolution)
        end_line_02 = len(line_02_points)
        for i in range(end_line_01, end_line_02):
            p_line_02 = line_02_points[i]
            p_line_12 = line_12_points[i-end_line_01] 
            vert_points = self.get_line_points(p_line_02,p_line_12,
                              point_resolution=point_resolution)
            fill_points.update(vert_points)
        return fill_points

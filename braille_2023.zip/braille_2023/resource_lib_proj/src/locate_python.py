#locate_python.py
import sys,os 
print(os.path.dirname(sys.executable))

#while_heads_tails_count.py
import random
n_heads = 0
n_tails = 0
n_max = 9
n = 0
while n < n_max:
	n += 1
	num = random.randint(1,2)
	if num == 1:
		ht="heads"
		n_heads += 1
	else:
		ht="tails"
		n_tails += 1
	print(ht, "  NOW We have:", n_heads,"heads", n_tails, "tails")
#tree.py
width = 8
for i in range(width*2):
	bef = width-i
	print(
	print(i,i*".")

#while_random.py
import random
n_max = 9
n = 0
while n < n_max:
	n += 1
	num = random.randint(1,2)
	print(num)

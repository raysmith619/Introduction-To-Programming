# square.py
# Display a square
from turtle_braille_link import *        # Set link to library
width(10)
color("red")
forward(200)
right(90)
forward(200)
right(90)
forward(200)
right(90)
forward(200)
done()

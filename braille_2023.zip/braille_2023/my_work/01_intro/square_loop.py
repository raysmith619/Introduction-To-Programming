# square_loop.py
# Display a square

from turtle_braille_link import *    # Get graphics stuff
##from turtle import *

color("green")
for i in range(4):  # Do 4 times
    forward(200)
    right(90)
done()

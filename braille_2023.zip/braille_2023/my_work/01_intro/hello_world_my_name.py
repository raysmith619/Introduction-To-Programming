# hello_world_my_name.py

print("Hello World")
print("My Name is Ray")
print("I live in Watertown.")

# if_else.py
print("if_else.py")
a = 1
b = 2
if a < b:
	print("a:",a, "b:", b, "a<b")

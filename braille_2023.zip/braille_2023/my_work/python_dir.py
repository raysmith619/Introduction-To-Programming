import sys
import os
print(os.path.dirname(sys.executable))

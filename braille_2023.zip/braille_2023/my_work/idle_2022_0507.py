Python 3.10.2 (tags/v3.10.2:a58ebcc, Jan 17 2022, 14:12:15) [MSC v.1929 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
2+2
4
60*60*24*365.3
31561920.0
salary=1000
new_salary=1350
raise1 = new_salary-salary
raise1/salary
0.35
raise1/salary*100
35.0
print("hello")
hello

#while_n.py
n_max = 9
n = 0
while n < n_max:
	n += 1
	print(n)

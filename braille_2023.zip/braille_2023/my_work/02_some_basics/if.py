# if.py    11Jan2022  ???, if examples
print("if.py")
a = 11
b = 22
print("a:",a,"b:",b)
print("\nif a == b:")
if a == b:
    print("a:",a,"b:",b)

print("\nif a != b:")
if a != b:
    print("a:",a, "!=", "b:",b)

print("\nif a > b:")
if a > b:
    print("a:",a, ">", "b:",b)

print("\nif a < b:")
if a < b:
    print("a:",a, "<", "b:",b)

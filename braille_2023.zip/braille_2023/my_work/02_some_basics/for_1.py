#for_1.py
for i in [2, 4, 6, 8]:
    print("i:", i)

# quick_notes
Simple notes project for beginner programmers

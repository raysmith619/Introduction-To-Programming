#for_range_beg_end.py
beg = 1
end = 8
for i in range(beg, end):
    print("i:", i)
    

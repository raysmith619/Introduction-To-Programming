#emoji_1.py 01Dec2020  crs
# Play with emojis
emojis = "😀 😃 😄 😁 😆 😅 😂 🤣"
for em in emojis:
    if em != " ":
        print(em, end=":")
print()
for em in emojis:
    if em != " ":
        print(em, end=":")
print()

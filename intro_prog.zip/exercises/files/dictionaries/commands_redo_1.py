# commands_redo_1.py   26Aug2022  crs, Author
# Example of dictionay as command list

commands = {"up":1, "down":1, "left":1, "right":1}
print("commands:", commands)
for inp in ["up", "down", "in", "out"]:
    """
    Replace this with "if-else" statements
    to test and display which strings
    are found in the "commands" dictionary
    """

#dictionary1.py 03Oct2021  crs, from slide 3
#
#Dictionary  - Group of values - Access by key
trades_d = { 
    "painter" : "tom",
    "landscaper" : "joe",
    "plumber" : "kate"
    }
print("landscaper:", trades_d["landscaper"])
print("painter:", trades_d["painter"])

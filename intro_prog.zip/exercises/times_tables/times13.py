#times13.py crs 15Oct2018  original

#times table....
nval = 15      # number to multiply
first = 1
last = nval

n = first    # begin at lowest value
while n <= last:
    print(n, "x", nval, n*nval)
    n = n + 1

# Do this program using a for statement
#    using a range() function.
# How / when would that be a better choice?


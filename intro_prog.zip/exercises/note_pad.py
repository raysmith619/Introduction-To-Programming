# note_pad.py   02Oct2018
import subprocess as sp
fname = "notes.py"
sp.Popen(["notepad.exe", fname])

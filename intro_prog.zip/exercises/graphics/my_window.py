#my_window.py   15Aug2021  crs, very simple

import tkinter as tk

root = tk.Tk()
root.mainloop()

r'''
The following would also work
from tkinter import *
root = Tk()
mainloop()
'''






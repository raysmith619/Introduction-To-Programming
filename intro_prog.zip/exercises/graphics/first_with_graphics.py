# first_with_graphics 07Mar2019 crs
# loop asking number
# print number entered
from gr_input import *

while True:
    inp = gr_input("Enter Number ")
    num = int(inp)
    print("Number:", num)
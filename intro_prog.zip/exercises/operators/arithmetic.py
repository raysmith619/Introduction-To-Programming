# arithmetic.py 24Feb2022  crs
#Introduction to Python arithmetic operators
ia = 2
ib = 3
ic = 5
print("ia:",ia, "ib:", ib, "ic:", ic)
print("ia+ib:",ia+ib, "ia-ic:",ia-ic, "ib*ic:", ib*ic)
print("ia/ib:",ia/ib, "ia**ic:",ia**ic, "ib%ic:", ib%ic)
print("ia/ib:", ia/ib)
print("ia//ib:",ia//ib, "fixed point divide")
print("ia**ic:",ia**ic, "ib%ic:", ib%ic)

print("ia+ib*ic:", ia+ib*ic, "(ia+ib)*ic:", (ia+ib)*ic)
print("ia+(ib*ic):", ia+(ib*ic), "(ia+ib)*ic:", (ia+ib)*ic)

print("ia*ib**ic:", ia*ib**ic, "ia*(ib**ic):", ia*(ib**ic))
print("ia*(ib**ic):", ia*(ib**ic), "(ia*ib)**ic:", (ia*ib)**ic)

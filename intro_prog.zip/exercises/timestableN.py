# timestableN.py 14Jan2020
# times table program 1 x 13....
# Prompt user for number
inp = input("Enter Multiplicand:")
nval = int(inp)
last = nval
first = 1
n = first
while n <= last:
    print(n, "x", nval, "=", n*nval)
    n = n + 1
    
    


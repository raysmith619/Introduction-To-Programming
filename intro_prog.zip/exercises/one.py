# one.py 25-Jul-2018
print("HI")

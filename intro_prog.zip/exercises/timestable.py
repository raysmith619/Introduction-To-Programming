# timestable.py 14Jan2020
# times table program 1 x 13....
nval = 13
last = nval
first = 1
n = first
while n <= last:
    print(n, "x", nval, "=", n*nval)
    n = n + 1
    
    


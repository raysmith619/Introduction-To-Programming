# hello2.py  25Jul2018
print("Hello World!")
print("More Stuff")
print("HI")


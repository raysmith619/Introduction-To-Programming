#cards_card.py   07Oct2021   crs, author
#
"""
A cards_card "module" which can be used by other programs
"""
class CardsCard:
    """ Simple playing card class
    """
    suits = {"S":1,"H":1,"D":1,"C":1}
    ranks = {"A":14,"K":13,"Q":13,"J":12,
                 "10":10,"9":9,"8":8,"7":7,"6":6,
                 "5":5,"4":4,"3":3,"2":2,"1":1}
    rank2str = {14:"A", 13:"K", 12:"Q", 11:"J",
                10:"10", 9:"9", 8:"8", 7:"7", 6:"6",
                5:"5", 4:"4", 3:"3", 2:"2", 1: 1}
    def __init__(self, string):
        """ Setup card
        :str_string: Descriptive sting
        (S|H|D|C) ":" A|K|Q|J|10|9..1
        # e.g., "S:A" for Ace of Spades
        """
        suit, rank_str = string.split(":")
        suit = suit.upper()
        if suit in CardsCard.suits:
            self.suit = suit
        else:
            raise Exception(f"Bad card{string} - suit:{suit}")
        if rank_str in CardsCard.ranks:
            rank = CardsCard.ranks[rank_str]
            self.rank = rank_str
        else:
            raise Exception(f"Bad card{string} - rank:{rank_str}")
        self.value = CardsCard.ranks[self.rank]
    def __str__(self):
        st = self.suit + ":"
        st += self.rank
        return st
    
"""
Do testing
"""    
if __name__ == "__main__":
    print("Self test", __file__)
    for rank_str in CardsCard.ranks:
        for suit in ["C", "D", "H", "S"]:
            cs = f"{suit}:{rank_str}"
            card = CardsCard(cs)
            print(f" {cs}=>card: {card} value:{card.value}", end="")
        print()
            

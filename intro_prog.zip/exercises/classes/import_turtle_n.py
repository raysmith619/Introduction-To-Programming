#import_turtle_n.py     30Dec2021  crs, Author
"""
import <module>
Access each turtle function via turtle.<member_name>
"""
import turtle
t1 = turtle.Turtle()	# First obj
t2 = turtle.Turtle()	# Second obj

t1.color("red")
t2.color("blue")

t1.forward(100)
t1.right(60)
t1.forward(100)
t1.right(60)
t1.forward(100)

t2.right(45)
t2.forward(200)
t2.right(45)
t2.forward(200)
    

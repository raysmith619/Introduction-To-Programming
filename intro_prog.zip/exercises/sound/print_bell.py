#print_bell
print("\a")

#colors.py  03Aug2021  crs, Author
# Print simple list of colors
# Loop (iterate) through list – colors.py
colors = ["red", "orange", "yellow",
	    "green", "blue", "indigo",
    "violet"]
for color in colors:
    print(color)

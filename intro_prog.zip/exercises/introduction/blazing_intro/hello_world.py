# hello_world.py    27Dec2021  ??? - first program
print("Hello World!")
print("My name is Ray")

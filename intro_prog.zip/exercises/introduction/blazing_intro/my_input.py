# my_input.py    27Dec2021  crs - exercise input()
# Get user input from the keyboard
inp = input("Please enter number:")
print("You entered", inp)

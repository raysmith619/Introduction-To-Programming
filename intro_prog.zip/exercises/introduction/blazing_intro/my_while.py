# my_while.py    27Dec2021  crs - exercise while statement

print("my_while")
i = 1
max = 10
while i < max:
    print("i:", i, "max(", max, ")")
    i = i + 1

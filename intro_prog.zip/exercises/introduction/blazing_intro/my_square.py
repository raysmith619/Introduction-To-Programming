# my_square.py    11Jan2022  crs, turtle square
from turtle import *    # Turtle stuff
print("Make square")
clr = "blue"
side = 200
color(clr)
right(90)
forward(side)
right(90)
forward(side)
right(90)
forward(side)
right(90)
forward(side)



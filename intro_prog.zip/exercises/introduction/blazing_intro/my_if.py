# my_if.py    27Dec2021  crs - exercise if statement

a = 1
b = 2
c = 3
print("my_if")
if a == b:
    print("a ", a, " == ", " b ", b)
if a != b:
    print("a(", a, ") != ", " b(", b, ")")
if a < b:
    print("a(", a, ") < ", " b(", b, ")")

# python_introduction_review.py
# The following are review discussions/answers
# to the programming / python introduction presented in the
# file python_introduction.py.


>>> # Review

>>> a = 2;b=1
>>> if a > b:
	print("a")

	
a

>>> if a > b:
	print("a")
else:
	print("b")

	
a
>>> b = a +1
>>> if a > b:
	print("a")
else:
	print("b")

	
b


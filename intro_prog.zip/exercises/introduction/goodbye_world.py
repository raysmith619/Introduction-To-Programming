#goodbye_world.py 10Sep2020  crs, Author
print("Goodbye World!")
print("My name is Ray.")

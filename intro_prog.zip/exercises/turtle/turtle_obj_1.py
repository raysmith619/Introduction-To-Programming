#turtle_obj_1.py    21Dec2020  crs
"""
Object oriented turtle
"""
import turtle
t1 = turtle.Turtle()    # Create a turtle object
t1.color("red")
t1.right(90)
t1.forward(100)
t1.color("orange")
t1.right(90)
t1.forward(100)
t1.color("yellow")
t1.right(90)
t1.forward(100)
t1.color("green")
t1.right(90)
t1.forward(100)

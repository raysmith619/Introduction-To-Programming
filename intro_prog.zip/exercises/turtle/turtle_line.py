# turtle_line.py    26Oct2020 from
#  https://www.youtube.com/watch?v=pxKu2pQ7ILo
# Just a line
import turtle

ray = turtle.Turtle()
ray.forward(100)
ray.left(90)
ray.forward(50)

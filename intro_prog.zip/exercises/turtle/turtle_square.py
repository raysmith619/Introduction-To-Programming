# turtle_square.py    05Nov2020 from
#  https://www.youtube.com/watch?v=pxKu2pQ7ILo
# Make a square
from turtle import *
side = 100
color("blue")
forward(side)
left(90)
color("red")
forward(side)
left(90)
color("green")
forward(side)
left(90)
color("orange")
forward(side)

# turtle_line_2.py    26Oct2020 from
#  https://www.youtube.com/watch?v=pxKu2pQ7ILo
# Just a line
# + add color
import turtle

ray = turtle.Turtle()
ray.color("red")
ray.forward(100)
ray.left(90)
ray.forward(50)

#shortest_demo.py
#From turtle module documentation
from turtle import *
color('red', 'green')
begin_fill()
for i in range(50):
    forward(200)
    left(170)
end_fill()
done()

#shortest_demo_3.py
#From turtle module documentation
from turtle import *
for i in range(50):
    forward(200)
    left(170)

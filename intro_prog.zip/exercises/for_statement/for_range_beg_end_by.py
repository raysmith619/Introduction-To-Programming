#for_range_beg_end_by.py
beg = 1
end = 8
for i in range(beg, end, 2):
    print("i:", i)
    

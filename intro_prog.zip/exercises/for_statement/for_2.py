#for_2.py
for i in [2, 4, 6, 8]:
    print("i:", i)
    print("i**2:", i**2)
    

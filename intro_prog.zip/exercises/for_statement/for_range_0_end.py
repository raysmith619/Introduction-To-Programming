#for_range_0_end.py
end = 8    # One MORE than list
for i in range(end):
    print("i:", i)
    

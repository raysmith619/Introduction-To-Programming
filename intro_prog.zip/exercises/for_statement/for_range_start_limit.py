#for_range_start_limit.py
start = 1
limit = 8
print("start:", start, "limit:", limit)
for i in range(start, limit):
    print("i:", i)
    

#for_range_0_limit.py
limit = 8    # Up to but NOT including limit
print("limit:", limit)
for i in range(limit):
    print("i:", i)
    

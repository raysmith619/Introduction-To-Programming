#for_range_start_limit_inc.py
start = 1       # Starting number
limit = 8       # limit - stop at less
inc = 2         # Increment amount
print("start:", start, "limit:", limit, "inc:", inc)
for i in range(start, limit, inc):
    print("i:", i)
    

#for_3.py
for i in range(8):
    print("i:", i)
    

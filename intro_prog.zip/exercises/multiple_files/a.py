#a.py
print("a.py")

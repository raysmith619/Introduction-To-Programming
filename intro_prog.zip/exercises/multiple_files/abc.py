#abc.py
import a
import b
import c


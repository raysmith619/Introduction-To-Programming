#c.py
print("c.py")

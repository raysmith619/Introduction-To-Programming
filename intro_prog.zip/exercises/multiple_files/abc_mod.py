#abc_mod.py
from a_mod import *
from b_mod import *
from c_mod import *
a_fun()
b_fun()
b_fun()
c_fun()
c_fun()
c_fun()

#b.py
print("b.py")

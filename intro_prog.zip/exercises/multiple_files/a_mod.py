#a_mod.py
def a_fun():
    print("a.py")

#list_friends.py    23Sep2020  crs, Author
# Simple List Example
"""
Just list a list of friends names
"""
# Initial list of friends names
my_friends = [
    "Ray Smith",
    "Phil Fontain",
    "Rich Parker",
    ]

# Simple loop to print out names from list
for name in my_friends:
    print(name)

r'''
Output:
>>> 
= RESTART: C:\Users\raysm\workspace\python
\IntroductionToProgramming\exercises\functions
\friends_family\simple_friends\list_friends.py
Ray Smith
Phil Fontain
Rich Parker
>>>
'''

# list_friends.py   08-Aug-2021  crs, Author
#Friends – Simple List Example / Exercise

"""
just print a list of friend names
"""
my_friends = ["ray", "sue", "joe"]
for name in my_friends:
    print(name)

"""
Output:
ray
sue
joe

"""

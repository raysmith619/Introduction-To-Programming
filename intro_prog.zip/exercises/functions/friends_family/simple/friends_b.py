#friends_b.py    03Jul2022   crs, author
"""
Simplest introduction to function tool building
A simple demonstration of functions' purpose  and use
"""
my_friends = []     # Initialize list of friends(names)
                    # as an empty list

"""
Do testing
"""
print("my_friends:", my_friends)
my_friends = ["Mary", "Tom", "Jane"]
print("my_friends:", my_friends)
my_friends.append("Ray")
print("my_friends:", my_friends)

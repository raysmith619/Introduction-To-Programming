#friends_a.py    03Jul2022   crs, author
"""
Simplest introduction to function tool building
A simple demonstration of functions' purpose  and use
"""
my_friends = []     # Initialize list of friends(names)
                    # as an empty list

"""
Do testing
"""
print("my_friends:", my_friends)

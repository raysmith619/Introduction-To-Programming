# first_2 17Jul2018
"""
loop asking number
print number entered
+
Set target and quit when input equals target

"""
while True:
    inp = input("Enter Number ")
    num = int(inp)
    print("Number:", num)

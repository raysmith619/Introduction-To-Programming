# t2.py 31Jul2018
# Set target value
# Quit if number entered number equals target

# loop asking number
# print number entered
while True:
    inp = input("Enter Number ")
    num = int(inp)
    print("Number:", num)

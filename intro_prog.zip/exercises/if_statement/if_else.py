# if_else.py    08Mar2022  ???, if examples
print("if_else.py")
a = 11
b = 22

print("a:",a,"b:",b)
print("\nif a == b:")
if a == b:
    print("a:",a,"b:",b)
else:
    print("else executed")
print("\nif a != b:")
if a != b:
    print("a:",a, "!=", "b:",b)
else:
    print("else executed")

print("\nif a > b:")
if a > b:
    print("a:",a, ">", "b:",b)
else:
    print("else executed")

print("\nif a < b:")
if a < b:
    print("a:",a, "<", "b:",b)
else:
    print("else executed")

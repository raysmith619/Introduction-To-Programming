# if_3_gt_2.py
if 3 > 2:
	print("if 3 > 2:", "if PASSED")

# if_3_gt_4_else.py
if 3 > 4:
	print("if 3 > 4: else:", "if PASSED")
else:
    print("if 3 > 4: else:", "else PASSED")

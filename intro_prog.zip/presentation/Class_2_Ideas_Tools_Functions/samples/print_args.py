#print_args.py
#Some samples of print, using sep, end
print('print("a", "b", "c")')
print("a", "b", "c")
print('\nprint("a", "b", "c", sep=":")')
print("a", "b", "c", sep=":")
print()
print('print("a", "b", "c", sep="")')
print("a", "b", "c", sep="")
print()
print("""
print("a", "b", "c", end="")
print("d", "e", "f")""")
print("a", "b", "c", end="")
print("d", "e", "f")

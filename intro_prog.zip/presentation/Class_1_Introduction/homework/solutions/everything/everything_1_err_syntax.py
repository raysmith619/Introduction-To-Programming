# everything_1_err_syntax.py
print("""Expected Error:
Traceback (most recent call last): File
  "C:/Users/raysm/workspace/python/
  IntroductionToProgramming/homework/Class_1_Introduction/
  everything_1_err_syntax.py",
  line 2, in <module> print('1 + "one":', 1 + "one")
  TypeError:
  unsupported operand type(s) for +: 'int' and 'str'
""")

print('1 + "one":', 1 + "one")

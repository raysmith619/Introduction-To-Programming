#everything_1_err_bad_name.py
last name = "Smith"

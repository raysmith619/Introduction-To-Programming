# some_input.py 24Feb2022  crs
# Keyboard input
inp = input("Please enter your name:")
name = inp
print("Hi", name)
